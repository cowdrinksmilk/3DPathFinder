Test: Forced to route over several hills at a ~30 degree angle

Elevation: Black pixels are 15 m higher than the other pixels.

Expected path: Straight line, distance should match exactly (-precision error)
Expected run time: <10s
