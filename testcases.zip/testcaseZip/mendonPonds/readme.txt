Test: Different paths in the actual park map

Expected path: Path and distance vary, just check if it looks reasonable - i.e. doesn't route through water, etc.
Expected run time: <20s
