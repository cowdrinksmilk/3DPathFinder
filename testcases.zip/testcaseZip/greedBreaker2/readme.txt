Test: Routes through 1 control point but has to move away from the goal in order to find it

Elevation: Flat

Expected path: Path and distance should match exactly. 
Expected run time: <10s
