Test: Routes through 4 control points, from one end to the other and then back. 

Elevation: Flat

Expected path: Path and distance should match exactly. 
Expected run time: <10s
