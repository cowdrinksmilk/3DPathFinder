Test: Forced to route through water. 
Elevation: Flat

Expected path: Straight line, distance should match exactly (-precision error)
Expected run time: <10s
