Test: Routes a "maze" with out-of-bound pixel "walls"

Elevation: Flat

Expected path: Straight line, distance should match exactly (-precision error)
Expected run time: <10s
