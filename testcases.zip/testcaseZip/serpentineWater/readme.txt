Test: Routes a "maze" with water pixel "walls"

Elevation: Flat

Expected path: The should snake around the water, distance should match exactly (-precision error).
Your water penalty should be high enough that you do not route through it to save <100 m

Expected run time: <10s
