Test: Long run meant to ensure the heuristic is working

Elevation: Flat

Expected path: Path and distance should match exactly (-precision error). 
Expected run time: <15s
