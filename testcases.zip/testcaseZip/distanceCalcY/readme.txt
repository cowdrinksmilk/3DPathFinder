Test: simple distance calculation test. Move along the y axis 

Elevation: Flat

Expected path: Path and distance should match exactly (-precision error). 
Expected run time: <10s
